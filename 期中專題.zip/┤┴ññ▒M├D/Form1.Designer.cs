﻿namespace 期中專題
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbCommentID = new System.Windows.Forms.ListBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabNews = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.tabIndex = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabMember = new System.Windows.Forms.TabPage();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.txtGender = new System.Windows.Forms.TextBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.txtNN = new System.Windows.Forms.TextBox();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.txtPhoto = new System.Windows.Forms.TextBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.txtCN = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.txtAdd = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.errorADD = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAcc = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.tabBlog = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.lbBlogComments = new System.Windows.Forms.ListBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.panel19 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.labelCat = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblAuthorDate = new System.Windows.Forms.Label();
            this.cbBlogCategory = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.btnCommentUpdate = new System.Windows.Forms.Button();
            this.btnCommentDelete = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.labcomment = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.tabReport = new System.Windows.Forms.TabPage();
            this.tabreserve = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioItemAll = new System.Windows.Forms.RadioButton();
            this.ItemCheck = new System.Windows.Forms.CheckedListBox();
            this.btnItemClear = new System.Windows.Forms.Button();
            this.btnItemCompare = new System.Windows.Forms.Button();
            this.btnReserve = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioProjectAll = new System.Windows.Forms.RadioButton();
            this.listBoxProjectItem = new System.Windows.Forms.ListBox();
            this.comboboxProject = new System.Windows.Forms.ComboBox();
            this.testLbl = new System.Windows.Forms.Label();
            this.PlanDescription = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboboxPlan = new System.Windows.Forms.ComboBox();
            this.labelSum = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.listViewItemsAll = new System.Windows.Forms.ListView();
            this.dataGridViewTest = new System.Windows.Forms.DataGridView();
            this.tabcar = new System.Windows.Forms.TabPage();
            this.button16 = new System.Windows.Forms.Button();
            this.ListViewCart = new System.Windows.Forms.ListView();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.entityCommand1 = new System.Data.Entity.Core.EntityClient.EntityCommand();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.button6 = new System.Windows.Forms.Button();
            this.RPview2 = new System.Windows.Forms.ListView();
            this.RPbox1 = new System.Windows.Forms.ListBox();
            this.RPview1 = new System.Windows.Forms.ListView();
            this.RPbtn2 = new System.Windows.Forms.Button();
            this.RPbtn1 = new System.Windows.Forms.Button();
            this.labReportDate = new System.Windows.Forms.Label();
            this.labDate = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabNews.SuspendLayout();
            this.tabIndex.SuspendLayout();
            this.tabMember.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.tabBlog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.tabReport.SuspendLayout();
            this.tabreserve.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTest)).BeginInit();
            this.tabcar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(232)))), ((int)(((byte)(197)))));
            this.panel1.Controls.Add(this.lbCommentID);
            this.panel1.Controls.Add(this.button9);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(227, 876);
            this.panel1.TabIndex = 0;
            // 
            // lbCommentID
            // 
            this.lbCommentID.FormattingEnabled = true;
            this.lbCommentID.ItemHeight = 12;
            this.lbCommentID.Location = new System.Drawing.Point(174, 591);
            this.lbCommentID.Name = "lbCommentID";
            this.lbCommentID.Size = new System.Drawing.Size(53, 172);
            this.lbCommentID.TabIndex = 8;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(232)))), ((int)(((byte)(197)))));
            this.button9.Dock = System.Windows.Forms.DockStyle.Top;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button9.Image = ((System.Drawing.Image)(resources.GetObject("button9.Image")));
            this.button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.Location = new System.Drawing.Point(0, 517);
            this.button9.Name = "button9";
            this.button9.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button9.Size = new System.Drawing.Size(227, 66);
            this.button9.TabIndex = 6;
            this.button9.Text = "部落格";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click_1);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(232)))), ((int)(((byte)(197)))));
            this.button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(0, 451);
            this.button5.Name = "button5";
            this.button5.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button5.Size = new System.Drawing.Size(227, 66);
            this.button5.TabIndex = 5;
            this.button5.Text = "健康新知";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(232)))), ((int)(((byte)(197)))));
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(0, 385);
            this.button4.Name = "button4";
            this.button4.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button4.Size = new System.Drawing.Size(227, 66);
            this.button4.TabIndex = 4;
            this.button4.Text = "購物商城";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(232)))), ((int)(((byte)(197)))));
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(0, 319);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button3.Size = new System.Drawing.Size(227, 66);
            this.button3.TabIndex = 3;
            this.button3.Text = "線上預約";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(232)))), ((int)(((byte)(197)))));
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(0, 253);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(227, 66);
            this.button2.TabIndex = 2;
            this.button2.Text = "會員中心";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(232)))), ((int)(((byte)(197)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Default;
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 187);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(227, 66);
            this.button1.TabIndex = 1;
            this.button1.Text = "健檢報告";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button8);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(227, 187);
            this.panel2.TabIndex = 0;
            // 
            // button8
            // 
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(0, 0);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(227, 187);
            this.button8.TabIndex = 0;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(232)))), ((int)(((byte)(197)))));
            this.panel3.Controls.Add(this.label7);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(227, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1332, 149);
            this.panel3.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(374, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(291, 81);
            this.label7.TabIndex = 1;
            this.label7.Text = "會員資料";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(227, 149);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1332, 38);
            this.panel4.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(6, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(413, 24);
            this.label4.TabIndex = 4;
            this.label4.Text = "健康新知 =======================";
            // 
            // panel5
            // 
            this.panel5.Location = new System.Drawing.Point(0, 32);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(778, 586);
            this.panel5.TabIndex = 3;
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabNews);
            this.tabControl1.Controls.Add(this.tabIndex);
            this.tabControl1.Controls.Add(this.tabMember);
            this.tabControl1.Controls.Add(this.tabBlog);
            this.tabControl1.Controls.Add(this.tabReport);
            this.tabControl1.Controls.Add(this.tabreserve);
            this.tabControl1.Controls.Add(this.tabcar);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ItemSize = new System.Drawing.Size(0, 1);
            this.tabControl1.Location = new System.Drawing.Point(227, 187);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1332, 689);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 0;
            // 
            // tabNews
            // 
            this.tabNews.Controls.Add(this.label5);
            this.tabNews.Location = new System.Drawing.Point(4, 5);
            this.tabNews.Name = "tabNews";
            this.tabNews.Padding = new System.Windows.Forms.Padding(3);
            this.tabNews.Size = new System.Drawing.Size(1324, 680);
            this.tabNews.TabIndex = 1;
            this.tabNews.Text = "tabNews";
            this.tabNews.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(68, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(138, 26);
            this.label5.TabIndex = 0;
            this.label5.Text = "健康新知頁面";
            // 
            // tabIndex
            // 
            this.tabIndex.Controls.Add(this.label15);
            this.tabIndex.Controls.Add(this.label3);
            this.tabIndex.Location = new System.Drawing.Point(4, 5);
            this.tabIndex.Name = "tabIndex";
            this.tabIndex.Size = new System.Drawing.Size(1324, 680);
            this.tabIndex.TabIndex = 2;
            this.tabIndex.Text = "tabPage1";
            this.tabIndex.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("微軟正黑體", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label15.Location = new System.Drawing.Point(27, 127);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(163, 81);
            this.label15.TabIndex = 1;
            this.label15.Text = "主頁";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(27, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 81);
            this.label3.TabIndex = 0;
            this.label3.Text = "主頁";
            // 
            // tabMember
            // 
            this.tabMember.Controls.Add(this.panel18);
            this.tabMember.Controls.Add(this.panel17);
            this.tabMember.Controls.Add(this.panel16);
            this.tabMember.Controls.Add(this.panel15);
            this.tabMember.Controls.Add(this.panel13);
            this.tabMember.Controls.Add(this.panel14);
            this.tabMember.Controls.Add(this.label18);
            this.tabMember.Controls.Add(this.panel12);
            this.tabMember.Controls.Add(this.label16);
            this.tabMember.Controls.Add(this.errorADD);
            this.tabMember.Controls.Add(this.panel11);
            this.tabMember.Controls.Add(this.panel10);
            this.tabMember.Controls.Add(this.button10);
            this.tabMember.Location = new System.Drawing.Point(4, 5);
            this.tabMember.Name = "tabMember";
            this.tabMember.Size = new System.Drawing.Size(1324, 680);
            this.tabMember.TabIndex = 3;
            this.tabMember.Text = "tabPage1";
            this.tabMember.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.label25);
            this.panel18.Controls.Add(this.txtGender);
            this.panel18.Location = new System.Drawing.Point(592, 248);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(215, 39);
            this.panel18.TabIndex = 25;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label25.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label25.Location = new System.Drawing.Point(7, 6);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(90, 21);
            this.label25.TabIndex = 1;
            this.label25.Text = "姓　別　：";
            // 
            // txtGender
            // 
            this.txtGender.Location = new System.Drawing.Point(103, 6);
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(100, 22);
            this.txtGender.TabIndex = 0;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.label24);
            this.panel17.Controls.Add(this.txtNN);
            this.panel17.Location = new System.Drawing.Point(592, 203);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(215, 39);
            this.panel17.TabIndex = 21;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label24.Location = new System.Drawing.Point(7, 6);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(90, 21);
            this.label24.TabIndex = 1;
            this.label24.Text = "暱　稱　：";
            // 
            // txtNN
            // 
            this.txtNN.Location = new System.Drawing.Point(103, 6);
            this.txtNN.Name = "txtNN";
            this.txtNN.Size = new System.Drawing.Size(100, 22);
            this.txtNN.TabIndex = 0;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.label23);
            this.panel16.Controls.Add(this.txtName);
            this.panel16.Location = new System.Drawing.Point(592, 158);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(215, 39);
            this.panel16.TabIndex = 19;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label23.Location = new System.Drawing.Point(7, 6);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(90, 21);
            this.label23.TabIndex = 1;
            this.label23.Text = "姓　名　：";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(103, 6);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(100, 22);
            this.txtName.TabIndex = 0;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label22);
            this.panel15.Controls.Add(this.txtEmail);
            this.panel15.Location = new System.Drawing.Point(302, 248);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(215, 39);
            this.panel15.TabIndex = 17;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label22.Location = new System.Drawing.Point(7, 6);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(90, 21);
            this.label22.TabIndex = 1;
            this.label22.Text = "電子信箱：";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(103, 6);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(100, 22);
            this.txtEmail.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.label20);
            this.panel13.Controls.Add(this.txtPhoto);
            this.panel13.Location = new System.Drawing.Point(302, 438);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(215, 39);
            this.panel13.TabIndex = 22;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label20.Location = new System.Drawing.Point(7, 6);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(90, 21);
            this.label20.TabIndex = 1;
            this.label20.Text = "手機號碼：";
            // 
            // txtPhoto
            // 
            this.txtPhoto.Location = new System.Drawing.Point(103, 6);
            this.txtPhoto.Name = "txtPhoto";
            this.txtPhoto.Size = new System.Drawing.Size(100, 22);
            this.txtPhoto.TabIndex = 0;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label21);
            this.panel14.Controls.Add(this.txtCN);
            this.panel14.Location = new System.Drawing.Point(301, 483);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(215, 39);
            this.panel14.TabIndex = 23;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label21.Location = new System.Drawing.Point(7, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(90, 21);
            this.label21.TabIndex = 1;
            this.label21.Text = "連絡電話：";
            // 
            // txtCN
            // 
            this.txtCN.Location = new System.Drawing.Point(103, 6);
            this.txtCN.Name = "txtCN";
            this.txtCN.Size = new System.Drawing.Size(100, 22);
            this.txtCN.TabIndex = 0;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(524, 341);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 12);
            this.label18.TabIndex = 24;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.label19);
            this.panel12.Controls.Add(this.txtAdd);
            this.panel12.Location = new System.Drawing.Point(302, 393);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(215, 39);
            this.panel12.TabIndex = 20;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label19.Location = new System.Drawing.Point(7, 6);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(90, 21);
            this.label19.TabIndex = 1;
            this.label19.Text = "住址　　：";
            // 
            // txtAdd
            // 
            this.txtAdd.Location = new System.Drawing.Point(103, 6);
            this.txtAdd.Name = "txtAdd";
            this.txtAdd.Size = new System.Drawing.Size(100, 22);
            this.txtAdd.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(524, 217);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(0, 12);
            this.label16.TabIndex = 18;
            // 
            // errorADD
            // 
            this.errorADD.AutoSize = true;
            this.errorADD.Location = new System.Drawing.Point(524, 172);
            this.errorADD.Name = "errorADD";
            this.errorADD.Size = new System.Drawing.Size(0, 12);
            this.errorADD.TabIndex = 15;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.label17);
            this.panel11.Controls.Add(this.txtPass);
            this.panel11.Location = new System.Drawing.Point(302, 203);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(215, 39);
            this.panel11.TabIndex = 16;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label17.Location = new System.Drawing.Point(7, 6);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 21);
            this.label17.TabIndex = 1;
            this.label17.Text = "會員密碼：";
            // 
            // txtPass
            // 
            this.txtPass.Location = new System.Drawing.Point(103, 6);
            this.txtPass.Name = "txtPass";
            this.txtPass.Size = new System.Drawing.Size(100, 22);
            this.txtPass.TabIndex = 0;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label6);
            this.panel10.Controls.Add(this.txtAcc);
            this.panel10.Location = new System.Drawing.Point(302, 158);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(215, 39);
            this.panel10.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(7, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 21);
            this.label6.TabIndex = 1;
            this.label6.Text = "會員帳號：";
            // 
            // txtAcc
            // 
            this.txtAcc.Location = new System.Drawing.Point(103, 6);
            this.txtAcc.Name = "txtAcc";
            this.txtAcc.Size = new System.Drawing.Size(100, 22);
            this.txtAcc.TabIndex = 0;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(926, 194);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(97, 52);
            this.button10.TabIndex = 13;
            this.button10.Text = "更新資料";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click_1);
            // 
            // tabBlog
            // 
            this.tabBlog.Controls.Add(this.splitContainer1);
            this.tabBlog.Location = new System.Drawing.Point(4, 5);
            this.tabBlog.Name = "tabBlog";
            this.tabBlog.Size = new System.Drawing.Size(1324, 680);
            this.tabBlog.TabIndex = 4;
            this.tabBlog.Text = "tabPage1";
            this.tabBlog.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.AutoScroll = true;
            this.splitContainer1.Panel1.Controls.Add(this.panel20);
            this.splitContainer1.Panel1.Controls.Add(this.panel19);
            this.splitContainer1.Panel1.Controls.Add(this.panel6);
            this.splitContainer1.Panel1.Controls.Add(this.label9);
            this.splitContainer1.Panel1.Controls.Add(this.comboBox2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.btnCommentUpdate);
            this.splitContainer1.Panel2.Controls.Add(this.btnCommentDelete);
            this.splitContainer1.Panel2.Controls.Add(this.button17);
            this.splitContainer1.Panel2.Controls.Add(this.labcomment);
            this.splitContainer1.Panel2.Controls.Add(this.textBox1);
            this.splitContainer1.Panel2.Controls.Add(this.panel9);
            this.splitContainer1.Panel2.Controls.Add(this.panel7);
            this.splitContainer1.Panel2.Controls.Add(this.panel8);
            this.splitContainer1.Size = new System.Drawing.Size(1324, 680);
            this.splitContainer1.SplitterDistance = 891;
            this.splitContainer1.TabIndex = 4;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.panel21);
            this.panel20.Controls.Add(this.lbBlogComments);
            this.panel20.Controls.Add(this.richTextBox1);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel20.Location = new System.Drawing.Point(0, 514);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(874, 559);
            this.panel20.TabIndex = 42;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.panel22);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel21.Location = new System.Drawing.Point(0, 459);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(874, 100);
            this.panel21.TabIndex = 8;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.button11);
            this.panel22.Controls.Add(this.button12);
            this.panel22.Controls.Add(this.button13);
            this.panel22.Controls.Add(this.button14);
            this.panel22.Controls.Add(this.label8);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel22.Location = new System.Drawing.Point(0, 0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(874, 199);
            this.panel22.TabIndex = 43;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(28, 29);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 35;
            this.button11.Text = "<<";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(109, 29);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 36;
            this.button12.Text = "<";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(345, 29);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 23);
            this.button13.TabIndex = 37;
            this.button13.Text = ">";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(426, 29);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 23);
            this.button14.TabIndex = 38;
            this.button14.Text = ">>";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(249, 40);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(33, 12);
            this.label8.TabIndex = 39;
            this.label8.Text = "label8";
            // 
            // lbBlogComments
            // 
            this.lbBlogComments.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbBlogComments.FormattingEnabled = true;
            this.lbBlogComments.ItemHeight = 12;
            this.lbBlogComments.Location = new System.Drawing.Point(0, 293);
            this.lbBlogComments.Margin = new System.Windows.Forms.Padding(2);
            this.lbBlogComments.Name = "lbBlogComments";
            this.lbBlogComments.ScrollAlwaysVisible = true;
            this.lbBlogComments.Size = new System.Drawing.Size(874, 220);
            this.lbBlogComments.TabIndex = 23;
            this.lbBlogComments.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(874, 293);
            this.richTextBox1.TabIndex = 19;
            this.richTextBox1.Text = "";
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.pictureBox2);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel19.Location = new System.Drawing.Point(0, 80);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(874, 434);
            this.panel19.TabIndex = 41;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(874, 434);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel6.Controls.Add(this.labelCat);
            this.panel6.Controls.Add(this.lblTitle);
            this.panel6.Controls.Add(this.lblAuthorDate);
            this.panel6.Controls.Add(this.cbBlogCategory);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(874, 80);
            this.panel6.TabIndex = 40;
            // 
            // labelCat
            // 
            this.labelCat.AutoSize = true;
            this.labelCat.Location = new System.Drawing.Point(134, 54);
            this.labelCat.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelCat.Name = "labelCat";
            this.labelCat.Size = new System.Drawing.Size(134, 12);
            this.labelCat.TabIndex = 35;
            this.labelCat.Text = "Author Date 瀏覽次數:0人";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Consolas", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(2, 2);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(89, 32);
            this.lblTitle.TabIndex = 15;
            this.lblTitle.Text = "11111";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAuthorDate
            // 
            this.lblAuthorDate.AutoSize = true;
            this.lblAuthorDate.Location = new System.Drawing.Point(344, 54);
            this.lblAuthorDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAuthorDate.Name = "lblAuthorDate";
            this.lblAuthorDate.Size = new System.Drawing.Size(134, 12);
            this.lblAuthorDate.TabIndex = 16;
            this.lblAuthorDate.Text = "Author Date 瀏覽次數:0人";
            // 
            // cbBlogCategory
            // 
            this.cbBlogCategory.FormattingEnabled = true;
            this.cbBlogCategory.Location = new System.Drawing.Point(8, 47);
            this.cbBlogCategory.Name = "cbBlogCategory";
            this.cbBlogCategory.Size = new System.Drawing.Size(121, 20);
            this.cbBlogCategory.TabIndex = 34;
            this.cbBlogCategory.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(35, -92);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 19);
            this.label9.TabIndex = 18;
            this.label9.Text = "文章類別:";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(122, -92);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(92, 20);
            this.comboBox2.TabIndex = 17;
            // 
            // btnCommentUpdate
            // 
            this.btnCommentUpdate.Location = new System.Drawing.Point(174, 562);
            this.btnCommentUpdate.Name = "btnCommentUpdate";
            this.btnCommentUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnCommentUpdate.TabIndex = 15;
            this.btnCommentUpdate.Text = "修改";
            this.btnCommentUpdate.UseVisualStyleBackColor = true;
            this.btnCommentUpdate.Click += new System.EventHandler(this.btnCommentUpdate_Click);
            // 
            // btnCommentDelete
            // 
            this.btnCommentDelete.Location = new System.Drawing.Point(94, 565);
            this.btnCommentDelete.Name = "btnCommentDelete";
            this.btnCommentDelete.Size = new System.Drawing.Size(75, 23);
            this.btnCommentDelete.TabIndex = 14;
            this.btnCommentDelete.Text = "刪除";
            this.btnCommentDelete.UseVisualStyleBackColor = true;
            this.btnCommentDelete.Click += new System.EventHandler(this.btnCommentDelete_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(12, 565);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(75, 23);
            this.button17.TabIndex = 13;
            this.button17.Text = "送出";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // labcomment
            // 
            this.labcomment.AutoSize = true;
            this.labcomment.Location = new System.Drawing.Point(11, 476);
            this.labcomment.Name = "labcomment";
            this.labcomment.Size = new System.Drawing.Size(29, 12);
            this.labcomment.TabIndex = 10;
            this.labcomment.Text = "留言";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(11, 514);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(250, 22);
            this.textBox1.TabIndex = 8;
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.label12);
            this.panel9.Controls.Add(this.pictureBox5);
            this.panel9.Location = new System.Drawing.Point(12, 316);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(257, 139);
            this.panel9.TabIndex = 6;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(175, 4);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 12);
            this.label12.TabIndex = 1;
            this.label12.Text = "label12";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(0, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(168, 139);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.label10);
            this.panel7.Controls.Add(this.pictureBox3);
            this.panel7.Location = new System.Drawing.Point(11, 20);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(257, 139);
            this.panel7.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(175, 4);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 12);
            this.label10.TabIndex = 1;
            this.label10.Text = "label10";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(168, 139);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.label11);
            this.panel8.Controls.Add(this.pictureBox4);
            this.panel8.Location = new System.Drawing.Point(11, 170);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(257, 139);
            this.panel8.TabIndex = 7;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(175, 4);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(39, 12);
            this.label11.TabIndex = 1;
            this.label11.Text = "label11";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(0, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(168, 139);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // tabReport
            // 
            this.tabReport.Controls.Add(this.button6);
            this.tabReport.Controls.Add(this.RPview2);
            this.tabReport.Controls.Add(this.RPbox1);
            this.tabReport.Controls.Add(this.RPview1);
            this.tabReport.Controls.Add(this.RPbtn2);
            this.tabReport.Controls.Add(this.RPbtn1);
            this.tabReport.Controls.Add(this.labReportDate);
            this.tabReport.Controls.Add(this.labDate);
            this.tabReport.Controls.Add(this.label26);
            this.tabReport.Location = new System.Drawing.Point(4, 5);
            this.tabReport.Name = "tabReport";
            this.tabReport.Size = new System.Drawing.Size(1324, 680);
            this.tabReport.TabIndex = 5;
            this.tabReport.Text = "tabReport";
            this.tabReport.UseVisualStyleBackColor = true;
            // 
            // tabreserve
            // 
            this.tabreserve.Controls.Add(this.groupBox2);
            this.tabreserve.Controls.Add(this.btnItemClear);
            this.tabreserve.Controls.Add(this.btnItemCompare);
            this.tabreserve.Controls.Add(this.btnReserve);
            this.tabreserve.Controls.Add(this.groupBox3);
            this.tabreserve.Controls.Add(this.testLbl);
            this.tabreserve.Controls.Add(this.PlanDescription);
            this.tabreserve.Controls.Add(this.groupBox1);
            this.tabreserve.Controls.Add(this.labelSum);
            this.tabreserve.Controls.Add(this.label28);
            this.tabreserve.Controls.Add(this.listViewItemsAll);
            this.tabreserve.Controls.Add(this.dataGridViewTest);
            this.tabreserve.Location = new System.Drawing.Point(4, 5);
            this.tabreserve.Name = "tabreserve";
            this.tabreserve.Size = new System.Drawing.Size(1324, 680);
            this.tabreserve.TabIndex = 6;
            this.tabreserve.Text = "tabPage1";
            this.tabreserve.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioItemAll);
            this.groupBox2.Controls.Add(this.ItemCheck);
            this.groupBox2.Location = new System.Drawing.Point(764, 173);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(364, 434);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "items";
            // 
            // radioItemAll
            // 
            this.radioItemAll.AutoSize = true;
            this.radioItemAll.Location = new System.Drawing.Point(17, 21);
            this.radioItemAll.Name = "radioItemAll";
            this.radioItemAll.Size = new System.Drawing.Size(47, 16);
            this.radioItemAll.TabIndex = 0;
            this.radioItemAll.TabStop = true;
            this.radioItemAll.Text = "全部";
            this.radioItemAll.UseVisualStyleBackColor = true;
            this.radioItemAll.CheckedChanged += new System.EventHandler(this.radioItemAll_CheckedChanged);
            // 
            // ItemCheck
            // 
            this.ItemCheck.CheckOnClick = true;
            this.ItemCheck.FormattingEnabled = true;
            this.ItemCheck.Location = new System.Drawing.Point(33, 47);
            this.ItemCheck.Name = "ItemCheck";
            this.ItemCheck.Size = new System.Drawing.Size(308, 361);
            this.ItemCheck.TabIndex = 1;
            this.ItemCheck.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.ItemCheck_ItemCheck);
            this.ItemCheck.SelectedIndexChanged += new System.EventHandler(this.ItemCheck_SelectedIndexChanged);
            // 
            // btnItemClear
            // 
            this.btnItemClear.Location = new System.Drawing.Point(579, 500);
            this.btnItemClear.Name = "btnItemClear";
            this.btnItemClear.Size = new System.Drawing.Size(87, 38);
            this.btnItemClear.TabIndex = 15;
            this.btnItemClear.Text = "listview清空";
            this.btnItemClear.UseVisualStyleBackColor = true;
            this.btnItemClear.Click += new System.EventHandler(this.btnItemClear_Click);
            // 
            // btnItemCompare
            // 
            this.btnItemCompare.Location = new System.Drawing.Point(470, 500);
            this.btnItemCompare.Name = "btnItemCompare";
            this.btnItemCompare.Size = new System.Drawing.Size(87, 38);
            this.btnItemCompare.TabIndex = 14;
            this.btnItemCompare.Text = "方案比較";
            this.btnItemCompare.UseVisualStyleBackColor = true;
            this.btnItemCompare.Click += new System.EventHandler(this.btnItemCompare_Click);
            // 
            // btnReserve
            // 
            this.btnReserve.Location = new System.Drawing.Point(355, 500);
            this.btnReserve.Name = "btnReserve";
            this.btnReserve.Size = new System.Drawing.Size(88, 38);
            this.btnReserve.TabIndex = 13;
            this.btnReserve.Text = "送出";
            this.btnReserve.UseVisualStyleBackColor = true;
            this.btnReserve.Click += new System.EventHandler(this.btnReserve_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioProjectAll);
            this.groupBox3.Controls.Add(this.listBoxProjectItem);
            this.groupBox3.Controls.Add(this.comboboxProject);
            this.groupBox3.Location = new System.Drawing.Point(364, 173);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(261, 291);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "project";
            // 
            // radioProjectAll
            // 
            this.radioProjectAll.AutoSize = true;
            this.radioProjectAll.Location = new System.Drawing.Point(208, 22);
            this.radioProjectAll.Name = "radioProjectAll";
            this.radioProjectAll.Size = new System.Drawing.Size(47, 16);
            this.radioProjectAll.TabIndex = 2;
            this.radioProjectAll.TabStop = true;
            this.radioProjectAll.Text = "全部";
            this.radioProjectAll.UseVisualStyleBackColor = true;
            this.radioProjectAll.CheckedChanged += new System.EventHandler(this.radioProjectAll_CheckedChanged);
            // 
            // listBoxProjectItem
            // 
            this.listBoxProjectItem.ColumnWidth = 2;
            this.listBoxProjectItem.FormattingEnabled = true;
            this.listBoxProjectItem.ItemHeight = 12;
            this.listBoxProjectItem.Location = new System.Drawing.Point(14, 48);
            this.listBoxProjectItem.Name = "listBoxProjectItem";
            this.listBoxProjectItem.Size = new System.Drawing.Size(227, 220);
            this.listBoxProjectItem.TabIndex = 2;
            // 
            // comboboxProject
            // 
            this.comboboxProject.FormattingEnabled = true;
            this.comboboxProject.Location = new System.Drawing.Point(14, 22);
            this.comboboxProject.Name = "comboboxProject";
            this.comboboxProject.Size = new System.Drawing.Size(176, 20);
            this.comboboxProject.TabIndex = 0;
            this.comboboxProject.SelectedIndexChanged += new System.EventHandler(this.comboboxProject_SelectedIndexChanged);
            // 
            // testLbl
            // 
            this.testLbl.AutoSize = true;
            this.testLbl.Location = new System.Drawing.Point(762, 26);
            this.testLbl.Name = "testLbl";
            this.testLbl.Size = new System.Drawing.Size(39, 12);
            this.testLbl.TabIndex = 11;
            this.testLbl.Text = "label27";
            // 
            // PlanDescription
            // 
            this.PlanDescription.AutoEllipsis = true;
            this.PlanDescription.AutoSize = true;
            this.PlanDescription.Location = new System.Drawing.Point(362, 111);
            this.PlanDescription.Name = "PlanDescription";
            this.PlanDescription.Size = new System.Drawing.Size(56, 17);
            this.PlanDescription.TabIndex = 10;
            this.PlanDescription.Text = "description";
            this.PlanDescription.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PlanDescription.UseCompatibleTextRendering = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboboxPlan);
            this.groupBox1.Location = new System.Drawing.Point(364, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(352, 82);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Plan";
            // 
            // comboboxPlan
            // 
            this.comboboxPlan.FormattingEnabled = true;
            this.comboboxPlan.Location = new System.Drawing.Point(23, 36);
            this.comboboxPlan.Name = "comboboxPlan";
            this.comboboxPlan.Size = new System.Drawing.Size(296, 20);
            this.comboboxPlan.TabIndex = 0;
            this.comboboxPlan.SelectedIndexChanged += new System.EventHandler(this.comboboxPlan_SelectedIndexChanged);
            // 
            // labelSum
            // 
            this.labelSum.AutoSize = true;
            this.labelSum.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labelSum.Location = new System.Drawing.Point(114, 637);
            this.labelSum.Name = "labelSum";
            this.labelSum.Size = new System.Drawing.Size(22, 24);
            this.labelSum.TabIndex = 7;
            this.labelSum.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label28.Location = new System.Drawing.Point(49, 637);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(34, 17);
            this.label28.TabIndex = 6;
            this.label28.Text = "總計";
            // 
            // listViewItemsAll
            // 
            this.listViewItemsAll.GridLines = true;
            this.listViewItemsAll.HideSelection = false;
            this.listViewItemsAll.Location = new System.Drawing.Point(39, 209);
            this.listViewItemsAll.Name = "listViewItemsAll";
            this.listViewItemsAll.Size = new System.Drawing.Size(300, 415);
            this.listViewItemsAll.TabIndex = 4;
            this.listViewItemsAll.UseCompatibleStateImageBehavior = false;
            this.listViewItemsAll.View = System.Windows.Forms.View.Details;
            // 
            // dataGridViewTest
            // 
            this.dataGridViewTest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTest.Location = new System.Drawing.Point(27, 21);
            this.dataGridViewTest.Name = "dataGridViewTest";
            this.dataGridViewTest.RowTemplate.Height = 24;
            this.dataGridViewTest.Size = new System.Drawing.Size(312, 120);
            this.dataGridViewTest.TabIndex = 5;
            this.dataGridViewTest.Visible = false;
            // 
            // tabcar
            // 
            this.tabcar.Controls.Add(this.button16);
            this.tabcar.Controls.Add(this.ListViewCart);
            this.tabcar.Controls.Add(this.bindingNavigator1);
            this.tabcar.Controls.Add(this.label13);
            this.tabcar.Controls.Add(this.textBox3);
            this.tabcar.Controls.Add(this.button15);
            this.tabcar.Controls.Add(this.label2);
            this.tabcar.Controls.Add(this.textBox2);
            this.tabcar.Controls.Add(this.label1);
            this.tabcar.Controls.Add(this.dataGridView2);
            this.tabcar.Controls.Add(this.pictureBox1);
            this.tabcar.Location = new System.Drawing.Point(4, 5);
            this.tabcar.Name = "tabcar";
            this.tabcar.Size = new System.Drawing.Size(1324, 680);
            this.tabcar.TabIndex = 7;
            this.tabcar.Text = "cart";
            this.tabcar.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(605, 561);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 23);
            this.button16.TabIndex = 11;
            this.button16.Text = "付款";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // ListViewCart
            // 
            this.ListViewCart.GridLines = true;
            this.ListViewCart.HideSelection = false;
            this.ListViewCart.Location = new System.Drawing.Point(605, 14);
            this.ListViewCart.Name = "ListViewCart";
            this.ListViewCart.Size = new System.Drawing.Size(233, 530);
            this.ListViewCart.TabIndex = 10;
            this.ListViewCart.UseCompatibleStateImageBehavior = false;
            this.ListViewCart.View = System.Windows.Forms.View.Details;
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = null;
            this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator1.DeleteItem = null;
            this.bindingNavigator1.Dock = System.Windows.Forms.DockStyle.None;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2});
            this.bindingNavigator1.Location = new System.Drawing.Point(55, 319);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator1.Size = new System.Drawing.Size(201, 25);
            this.bindingNavigator1.TabIndex = 9;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(27, 22);
            this.bindingNavigatorCountItem.Text = "/{0}";
            this.bindingNavigatorCountItem.ToolTipText = "項目總數";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "移到最前面";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "移到上一個";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "位置";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "目前的位置";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "移到下一個";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "移到最後面";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label13.Location = new System.Drawing.Point(267, 276);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 31);
            this.label13.TabIndex = 7;
            this.label13.Text = "數量";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(372, 285);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 6;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(502, 285);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 23);
            this.button15.TabIndex = 5;
            this.button15.Text = "button15";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(49, 276);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 31);
            this.label2.TabIndex = 4;
            this.label2.Text = "label2";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(340, 85);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(237, 174);
            this.textBox2.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(334, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(55, 347);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(547, 197);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(55, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(247, 227);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // entityCommand1
            // 
            this.entityCommand1.CommandTimeout = 0;
            this.entityCommand1.CommandTree = null;
            this.entityCommand1.Connection = null;
            this.entityCommand1.EnablePlanCaching = true;
            this.entityCommand1.Transaction = null;
            // 
            // timer1
            // 
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 3000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // button6
            // 
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(112, 47);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(136, 128);
            this.button6.TabIndex = 35;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // RPview2
            // 
            this.RPview2.BackColor = System.Drawing.Color.White;
            this.RPview2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RPview2.HideSelection = false;
            this.RPview2.Location = new System.Drawing.Point(893, 279);
            this.RPview2.Name = "RPview2";
            this.RPview2.Size = new System.Drawing.Size(320, 354);
            this.RPview2.TabIndex = 34;
            this.RPview2.UseCompatibleStateImageBehavior = false;
            // 
            // RPbox1
            // 
            this.RPbox1.FormattingEnabled = true;
            this.RPbox1.ItemHeight = 12;
            this.RPbox1.Location = new System.Drawing.Point(652, 307);
            this.RPbox1.Name = "RPbox1";
            this.RPbox1.Size = new System.Drawing.Size(193, 88);
            this.RPbox1.TabIndex = 33;
            this.RPbox1.SelectedIndexChanged += new System.EventHandler(this.RPbox1_SelectedIndexChanged);
            // 
            // RPview1
            // 
            this.RPview1.BackColor = System.Drawing.Color.White;
            this.RPview1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RPview1.HideSelection = false;
            this.RPview1.Location = new System.Drawing.Point(279, 279);
            this.RPview1.Name = "RPview1";
            this.RPview1.Size = new System.Drawing.Size(320, 354);
            this.RPview1.TabIndex = 32;
            this.RPview1.UseCompatibleStateImageBehavior = false;
            // 
            // RPbtn2
            // 
            this.RPbtn2.Location = new System.Drawing.Point(770, 434);
            this.RPbtn2.Name = "RPbtn2";
            this.RPbtn2.Size = new System.Drawing.Size(75, 23);
            this.RPbtn2.TabIndex = 30;
            this.RPbtn2.Text = ">>";
            this.RPbtn2.UseVisualStyleBackColor = true;
            this.RPbtn2.Click += new System.EventHandler(this.RPbtn2_Click);
            // 
            // RPbtn1
            // 
            this.RPbtn1.Location = new System.Drawing.Point(625, 434);
            this.RPbtn1.Name = "RPbtn1";
            this.RPbtn1.Size = new System.Drawing.Size(75, 23);
            this.RPbtn1.TabIndex = 31;
            this.RPbtn1.Text = "<<";
            this.RPbtn1.UseVisualStyleBackColor = true;
            this.RPbtn1.Click += new System.EventHandler(this.RPbtn1_Click);
            // 
            // labReportDate
            // 
            this.labReportDate.AutoSize = true;
            this.labReportDate.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labReportDate.Location = new System.Drawing.Point(528, 182);
            this.labReportDate.Name = "labReportDate";
            this.labReportDate.Size = new System.Drawing.Size(242, 47);
            this.labReportDate.TabIndex = 29;
            this.labReportDate.Text = "健檢報告日期";
            this.labReportDate.Visible = false;
            // 
            // labDate
            // 
            this.labDate.AutoSize = true;
            this.labDate.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labDate.Location = new System.Drawing.Point(271, 182);
            this.labDate.Name = "labDate";
            this.labDate.Size = new System.Drawing.Size(242, 47);
            this.labDate.TabIndex = 28;
            this.labDate.Text = "健檢報告日期";
            this.labDate.Visible = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label26.Location = new System.Drawing.Point(271, 126);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(168, 47);
            this.label26.TabIndex = 27;
            this.label26.Text = "會員資料";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1559, 876);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.IsMdiContainer = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabNews.ResumeLayout(false);
            this.tabNews.PerformLayout();
            this.tabIndex.ResumeLayout(false);
            this.tabIndex.PerformLayout();
            this.tabMember.ResumeLayout(false);
            this.tabMember.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.tabBlog.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel19.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.tabReport.ResumeLayout(false);
            this.tabReport.PerformLayout();
            this.tabreserve.ResumeLayout(false);
            this.tabreserve.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTest)).EndInit();
            this.tabcar.ResumeLayout(false);
            this.tabcar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabNews;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TabPage tabIndex;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabMember;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabBlog;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tabReport;
        private System.Windows.Forms.TabPage tabreserve;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListBox lbBlogComments;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label lblAuthorDate;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Data.Entity.Core.EntityClient.EntityCommand entityCommand1;
        private System.Windows.Forms.ComboBox cbBlogCategory;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label labelCat;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label labcomment;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.TabPage tabcar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.ListView ListViewCart;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button btnCommentUpdate;
        private System.Windows.Forms.Button btnCommentDelete;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.ListBox lbCommentID;
        public System.Windows.Forms.Label testLbl;
        private System.Windows.Forms.Label PlanDescription;
        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.ComboBox comboboxPlan;
        public System.Windows.Forms.Label labelSum;
        private System.Windows.Forms.Label label28;
        public System.Windows.Forms.ListView listViewItemsAll;
        private System.Windows.Forms.DataGridView dataGridViewTest;
        private System.Windows.Forms.Button btnItemClear;
        private System.Windows.Forms.Button btnItemCompare;
        private System.Windows.Forms.Button btnReserve;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radioProjectAll;
        private System.Windows.Forms.ListBox listBoxProjectItem;
        private System.Windows.Forms.ComboBox comboboxProject;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioItemAll;
        private System.Windows.Forms.CheckedListBox ItemCheck;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtGender;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtNN;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtPhoto;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtCN;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtAdd;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label errorADD;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAcc;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.ListView RPview2;
        private System.Windows.Forms.ListBox RPbox1;
        private System.Windows.Forms.ListView RPview1;
        private System.Windows.Forms.Button RPbtn2;
        private System.Windows.Forms.Button RPbtn1;
        private System.Windows.Forms.Label labReportDate;
        private System.Windows.Forms.Label labDate;
        private System.Windows.Forms.Label label26;
    }
}

